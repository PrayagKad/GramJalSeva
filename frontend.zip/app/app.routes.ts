import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: '',
    loadComponent: () =>
      import('./components/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'water-logs',
        loadComponent: () =>
          import('./pages/water-log/water-log.component').then(m => m.WaterLogComponent)
      },
      {
        path: 'issues',
        loadComponent: () =>
          import('./pages/issues/issues.component').then(m => m.IssuesComponent)
      },
      {
        path: 'assets',
        loadComponent: () =>
          import('./pages/assets/assets.component').then(m => m.AssetsComponent)
      }
    ]
  },
  { path: '**', redirectTo: 'login' }
];
