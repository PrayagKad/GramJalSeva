import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/models';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    CommonModule, RouterOutlet, RouterLink, RouterLinkActive,
    MatSidenavModule, MatToolbarModule, MatListModule,
    MatIconModule, MatButtonModule, MatDividerModule, MatChipsModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">

      <mat-sidenav mode="side" opened class="sidenav">
        <div class="sidenav-header">
          <mat-icon class="logo-icon">water_drop</mat-icon>
          <div>
            <div class="app-title">ग्राम जल सेवा</div>
            <div class="app-subtitle">Village Water Monitor</div>
          </div>
        </div>

        <mat-divider />

        <div class="user-chip">
          <mat-icon>account_circle</mat-icon>
          <div class="user-info">
            <span class="user-name">{{ user?.name }}</span>
            <span class="user-role" [class.admin-badge]="isAdmin" [class.op-badge]="!isAdmin">
              {{ isAdmin ? 'Admin' : 'Operator' }}
            </span>
          </div>
        </div>

        <mat-divider />

        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active-link">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/water-logs" routerLinkActive="active-link">
            <mat-icon matListItemIcon>opacity</mat-icon>
            <span matListItemTitle>Water Logs</span>
          </a>
          <a mat-list-item routerLink="/issues" routerLinkActive="active-link">
            <mat-icon matListItemIcon>report_problem</mat-icon>
            <span matListItemTitle>Issues</span>
          </a>
          <a mat-list-item routerLink="/assets" routerLinkActive="active-link">
            <mat-icon matListItemIcon>build</mat-icon>
            <span matListItemTitle>Assets</span>
          </a>
        </mat-nav-list>

        <div class="sidenav-footer">
          <button mat-stroked-button color="warn" (click)="logout()">
            <mat-icon>logout</mat-icon> Logout
          </button>
        </div>
      </mat-sidenav>

      <mat-sidenav-content class="main-content">
        <router-outlet />
      </mat-sidenav-content>

    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container { height: 100vh; }

    .sidenav {
      width: 240px;
      display: flex;
      flex-direction: column;
      background: #1a237e;
      color: white;
    }

    .sidenav-header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 20px 16px;
    }

    .logo-icon {
      font-size: 36px;
      width: 36px;
      height: 36px;
      color: #90caf9;
    }

    .app-title {
      font-size: 16px;
      font-weight: 700;
      color: white;
      line-height: 1.2;
    }

    .app-subtitle {
      font-size: 11px;
      color: #90caf9;
      margin-top: 2px;
    }

    .user-chip {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 16px;
      color: white;
    }

    .user-chip mat-icon { color: #90caf9; }

    .user-info {
      display: flex;
      flex-direction: column;
    }

    .user-name {
      font-size: 13px;
      font-weight: 500;
      color: white;
    }

    .user-role {
      font-size: 10px;
      padding: 1px 6px;
      border-radius: 10px;
      margin-top: 3px;
      width: fit-content;
      font-weight: 600;
    }

    .admin-badge { background: #f59e0b; color: #1a1a1a; }
    .op-badge { background: #22c55e; color: #1a1a1a; }

    mat-nav-list {
      flex: 1;
      padding-top: 8px;
    }

    a[mat-list-item] {
      color: #b0bec5 !important;
      border-radius: 8px;
      margin: 2px 8px;
    }

    a[mat-list-item]:hover {
      background: rgba(255,255,255,0.1) !important;
      color: white !important;
    }

    .active-link {
      background: rgba(144,202,249,0.2) !important;
      color: #90caf9 !important;
    }

    .active-link mat-icon { color: #90caf9 !important; }

    mat-divider { border-color: rgba(255,255,255,0.15) !important; }

    .sidenav-footer {
      padding: 16px;
      margin-top: auto;
    }

    .sidenav-footer button {
      width: 100%;
      color: #ef9a9a !important;
      border-color: rgba(239,154,154,0.4) !important;
    }

    .main-content {
      background: #f5f5f5;
      overflow-y: auto;
    }
  `]
})
export class LayoutComponent implements OnInit {
  user: User | null = null;
  isAdmin = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }
    this.user = this.authService.getUser();
    this.isAdmin = this.authService.isAdmin();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
