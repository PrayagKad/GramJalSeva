import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatBadgeModule } from '@angular/material/badge';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { DashboardData, WaterLog } from '../../models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule, RouterLink,
    MatCardModule, MatIconModule, MatTableModule, MatBadgeModule,
    MatChipsModule, MatProgressBarModule, MatProgressSpinnerModule,
    MatDividerModule, MatButtonModule
  ],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h2 class="page-title">Dashboard</h2>
          <p class="page-subtitle">Real-time overview of the village water supply system</p>
        </div>
      </div>

      <div *ngIf="loading" class="loading-center">
        <mat-spinner diameter="48" />
      </div>

      <ng-container *ngIf="!loading && data">

        <!-- Summary Cards -->
        <div class="summary-grid">
          <mat-card class="summary-card card-blue">
            <mat-card-content>
              <div class="card-icon-row">
                <mat-icon>report_problem</mat-icon>
                <span class="card-label">Total Issues</span>
              </div>
              <div class="card-value">{{ data.totalIssues }}</div>
              <div class="card-sub">{{ data.openIssues }} open · {{ data.resolvedIssues }} resolved</div>
            </mat-card-content>
          </mat-card>

          <mat-card class="summary-card card-green">
            <mat-card-content>
              <div class="card-icon-row">
                <mat-icon>check_circle</mat-icon>
                <span class="card-label">Resolved Issues</span>
              </div>
              <div class="card-value">{{ data.resolvedIssues }}</div>
              <div class="card-sub">out of {{ data.totalIssues }} total</div>
            </mat-card-content>
          </mat-card>

          <mat-card class="summary-card card-amber">
            <mat-card-content>
              <div class="card-icon-row">
                <mat-icon>power</mat-icon>
                <span class="card-label">Active Pumps</span>
              </div>
              <div class="card-value">{{ data.activePumps }}</div>
              <div class="card-sub">pumps currently running</div>
            </mat-card-content>
          </mat-card>

          <mat-card class="summary-card card-teal">
            <mat-card-content>
              <div class="card-icon-row">
                <mat-icon>water</mat-icon>
                <span class="card-label">Latest Tank Level</span>
              </div>
              <div class="card-value">{{ data.latestTankLevel ?? '--' }}%</div>
              <div class="card-sub">{{ data.latestVillageName || 'No data yet' }}</div>
              <mat-progress-bar
                *ngIf="data.latestTankLevel != null"
                mode="determinate"
                [value]="data.latestTankLevel"
                [color]="data.latestTankLevel < 30 ? 'warn' : 'primary'"
                class="tank-bar"
              />
            </mat-card-content>
          </mat-card>
        </div>

        <!-- Recent Water Logs -->
        <mat-card class="logs-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">history</mat-icon>
            <mat-card-title>Recent Water Logs</mat-card-title>
            <mat-card-subtitle>Latest 10 entries across all villages</mat-card-subtitle>
            <div class="header-spacer"></div>
            <a mat-stroked-button routerLink="/water-logs" color="primary">View All</a>
          </mat-card-header>

          <mat-card-content>
            <table mat-table [dataSource]="data.recentLogs" class="logs-table">

              <ng-container matColumnDef="timestamp">
                <th mat-header-cell *matHeaderCellDef>Date & Time</th>
                <td mat-cell *matCellDef="let row">{{ row.timestamp | date:'dd MMM, hh:mm a' }}</td>
              </ng-container>

              <ng-container matColumnDef="villageName">
                <th mat-header-cell *matHeaderCellDef>Village</th>
                <td mat-cell *matCellDef="let row">
                  <span class="village-chip">{{ row.villageName }}</span>
                </td>
              </ng-container>

              <ng-container matColumnDef="tankLevel">
                <th mat-header-cell *matHeaderCellDef>Tank Level</th>
                <td mat-cell *matCellDef="let row">
                  <div class="tank-cell">
                    <mat-progress-bar
                      mode="determinate"
                      [value]="row.tankLevel"
                      [color]="row.tankLevel < 30 ? 'warn' : 'primary'"
                      class="inline-bar"
                    />
                    <span [class]="getTankClass(row.tankLevel)">{{ row.tankLevel }}%</span>
                  </div>
                </td>
              </ng-container>

              <ng-container matColumnDef="pumpStatus">
                <th mat-header-cell *matHeaderCellDef>Pump</th>
                <td mat-cell *matCellDef="let row">
                  <span class="status-badge" [class.on]="row.pumpStatus === 'ON'" [class.off]="row.pumpStatus === 'OFF'">
                    <span class="dot"></span>{{ row.pumpStatus }}
                  </span>
                </td>
              </ng-container>

              <ng-container matColumnDef="quality">
                <th mat-header-cell *matHeaderCellDef>Water Quality</th>
                <td mat-cell *matCellDef="let row">
                  <span class="quality-badge" [class.good]="row.quality === 'GOOD'" [class.bad]="row.quality === 'BAD'">
                    <mat-icon>{{ row.quality === 'GOOD' ? 'check' : 'close' }}</mat-icon>
                    {{ row.quality }}
                  </span>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>
          </mat-card-content>
        </mat-card>

      </ng-container>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; max-width: 1200px; }

    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 24px;
    }

    .page-title { font-size: 24px; font-weight: 600; margin: 0 0 4px; color: #1a237e; }
    .page-subtitle { font-size: 14px; color: #666; margin: 0; }

    .loading-center {
      display: flex;
      justify-content: center;
      padding: 80px;
    }

    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }

    .summary-card {
      border-radius: 12px !important;
      border-top: 4px solid transparent;
    }

    .card-blue { border-top-color: #1565c0 !important; }
    .card-green { border-top-color: #2e7d32 !important; }
    .card-amber { border-top-color: #f57f17 !important; }
    .card-teal { border-top-color: #00695c !important; }

    .card-icon-row {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
      color: #555;
    }

    .card-label { font-size: 13px; font-weight: 500; color: #666; }
    .card-value { font-size: 36px; font-weight: 700; color: #1a237e; line-height: 1; }
    .card-sub { font-size: 12px; color: #888; margin-top: 6px; }

    .tank-bar { margin-top: 10px; border-radius: 4px; }

    .logs-card { border-radius: 12px !important; }

    mat-card-header {
      display: flex;
      align-items: center;
      padding-bottom: 8px;
    }

    .header-icon { color: #1a237e; background: #e8eaf6; border-radius: 50%; padding: 6px; }
    .header-spacer { flex: 1; }

    .logs-table { width: 100%; }

    th { font-weight: 600; color: #444; font-size: 13px; }

    .village-chip {
      background: #e8eaf6;
      color: #3949ab;
      padding: 3px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }

    .tank-cell { display: flex; align-items: center; gap: 10px; min-width: 120px; }
    .inline-bar { width: 80px; border-radius: 4px; }

    .tank-good { color: #2e7d32; font-weight: 600; font-size: 13px; }
    .tank-warn { color: #f57f17; font-weight: 600; font-size: 13px; }
    .tank-critical { color: #c62828; font-weight: 600; font-size: 13px; }

    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 3px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }

    .status-badge .dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .status-badge.on { background: #e8f5e9; color: #2e7d32; }
    .status-badge.on .dot { background: #4caf50; }
    .status-badge.off { background: #fce4ec; color: #c62828; }
    .status-badge.off .dot { background: #ef5350; }

    .quality-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 3px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }

    .quality-badge mat-icon { font-size: 14px; width: 14px; height: 14px; }
    .quality-badge.good { background: #e8f5e9; color: #2e7d32; }
    .quality-badge.bad { background: #fce4ec; color: #c62828; }
  `]
})
export class DashboardComponent implements OnInit {
  data: DashboardData | null = null;
  loading = true;
  displayedColumns = ['timestamp', 'villageName', 'tankLevel', 'pumpStatus', 'quality'];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getDashboard().subscribe({
      next: (d) => { this.data = d; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getTankClass(level: number): string {
    if (level >= 60) return 'tank-good';
    if (level >= 30) return 'tank-warn';
    return 'tank-critical';
  }
}
