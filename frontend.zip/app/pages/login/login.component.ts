import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatIconModule, MatProgressSpinnerModule, MatSnackBarModule
  ],
  template: `
    <div class="login-wrapper">
      <div class="login-left">
        <div class="brand">
          <mat-icon class="brand-icon">water_drop</mat-icon>
          <h1>ग्राम जल सेवा</h1>
          <p>Village Water Monitoring System</p>
        </div>
        <div class="features">
          <div class="feature"><mat-icon>check_circle</mat-icon> Daily water level logging</div>
          <div class="feature"><mat-icon>check_circle</mat-icon> Issue tracking & resolution</div>
          <div class="feature"><mat-icon>check_circle</mat-icon> Asset management</div>
          <div class="feature"><mat-icon>check_circle</mat-icon> Admin dashboard</div>
        </div>
      </div>

      <div class="login-right">
        <mat-card class="login-card">
          <mat-card-header>
            <mat-card-title>Sign In</mat-card-title>
            <mat-card-subtitle>Enter your credentials to continue</mat-card-subtitle>
          </mat-card-header>

          <mat-card-content>
            <form [formGroup]="loginForm" (ngSubmit)="onLogin()">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Phone Number</mat-label>
                <mat-icon matPrefix>phone</mat-icon>
                <input matInput formControlName="phone" placeholder="e.g. 9876543210" maxlength="10" />
                <mat-error *ngIf="loginForm.get('phone')?.hasError('required')">Phone is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Password</mat-label>
                <mat-icon matPrefix>lock</mat-icon>
                <input matInput [type]="hidePass ? 'password' : 'text'" formControlName="password" />
                <button mat-icon-button matSuffix type="button" (click)="hidePass = !hidePass">
                  <mat-icon>{{ hidePass ? 'visibility_off' : 'visibility' }}</mat-icon>
                </button>
                <mat-error *ngIf="loginForm.get('password')?.hasError('required')">Password is required</mat-error>
              </mat-form-field>

              <button mat-raised-button color="primary" class="full-width login-btn"
                      type="submit" [disabled]="loading">
                <mat-spinner *ngIf="loading" diameter="20" />
                <span *ngIf="!loading">Sign In</span>
              </button>
            </form>
          </mat-card-content>

          <mat-card-footer>
            <div class="demo-creds">
              <strong>Demo Credentials</strong>
              <div>Admin: 9876543210 / admin123</div>
              <div>Operator: 9123456789 / op123</div>
            </div>
          </mat-card-footer>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .login-wrapper {
      display: flex;
      height: 100vh;
      background: #f5f5f5;
    }

    .login-left {
      flex: 1;
      background: linear-gradient(135deg, #1a237e 0%, #0d47a1 100%);
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 60px;
      color: white;
    }

    .brand {
      margin-bottom: 48px;
    }

    .brand-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #90caf9;
      display: block;
      margin-bottom: 16px;
    }

    .brand h1 {
      font-size: 32px;
      font-weight: 700;
      margin: 0 0 8px;
    }

    .brand p {
      font-size: 16px;
      color: #90caf9;
      margin: 0;
    }

    .features {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .feature {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 15px;
      color: #e3f2fd;
    }

    .feature mat-icon {
      color: #4caf50;
      font-size: 20px;
      width: 20px;
      height: 20px;
    }

    .login-right {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 420px;
      padding: 24px;
    }

    .login-card {
      width: 100%;
      padding: 16px;
    }

    mat-card-title { font-size: 22px !important; margin-bottom: 4px; }

    .full-width { width: 100%; margin-top: 16px; }

    .login-btn {
      height: 48px;
      font-size: 16px;
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .demo-creds {
      background: #e3f2fd;
      border-radius: 8px;
      padding: 12px 16px;
      margin: 16px;
      font-size: 13px;
      color: #1565c0;
      line-height: 1.8;
    }

    .demo-creds strong { display: block; margin-bottom: 4px; }

    @media (max-width: 768px) {
      .login-left { display: none; }
      .login-right { width: 100%; }
    }
  `]
})
export class LoginComponent {
  loginForm: FormGroup;
  loading = false;
  hidePass = true;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private auth: AuthService,
    private router: Router,
    private snack: MatSnackBar
  ) {
    this.loginForm = this.fb.group({
      phone: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onLogin(): void {
    if (this.loginForm.invalid) return;
    this.loading = true;
    const { phone, password } = this.loginForm.value;

    this.api.login(phone, password).subscribe({
      next: (user) => {
        this.auth.setUser(user);
        this.router.navigate(['/dashboard']);
      },
      error: () => {
        this.loading = false;
        this.snack.open('Invalid phone or password', 'Close', {
          duration: 3000, panelClass: ['error-snack']
        });
      }
    });
  }
}
