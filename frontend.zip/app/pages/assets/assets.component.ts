import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { ApiService } from '../../services/api.service';
import { Asset, Village } from '../../models/models';

@Component({
  selector: 'app-assets',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, MatProgressSpinnerModule,
    MatSnackBarModule, MatDialogModule, MatTooltipModule, MatChipsModule, MatDividerModule
  ],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h2 class="page-title">Asset Management</h2>
          <p class="page-subtitle">Manage pumps and tanks across villages</p>
        </div>
      </div>

      <div class="two-col">
        <!-- Form -->
        <mat-card class="form-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">{{ editingId ? 'edit' : 'add_circle' }}</mat-icon>
            <mat-card-title>{{ editingId ? 'Edit Asset' : 'Add Asset' }}</mat-card-title>
            <mat-card-subtitle>{{ editingId ? 'Update asset details' : 'Register a new pump or tank' }}</mat-card-subtitle>
          </mat-card-header>
          <mat-card-content>
            <form [formGroup]="assetForm" (ngSubmit)="onSubmit()">

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Village</mat-label>
                <mat-icon matPrefix>location_on</mat-icon>
                <mat-select formControlName="villageId">
                  <mat-option *ngFor="let v of villages" [value]="v.id">{{ v.name }}</mat-option>
                </mat-select>
                <mat-error>Village is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Asset Name</mat-label>
                <mat-icon matPrefix>label</mat-icon>
                <input matInput formControlName="name" placeholder="e.g. Main Pump A" />
                <mat-error>Name is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Type</mat-label>
                <mat-icon matPrefix>category</mat-icon>
                <mat-select formControlName="type">
                  <mat-option value="PUMP">PUMP</mat-option>
                  <mat-option value="TANK">TANK</mat-option>
                </mat-select>
                <mat-error>Type is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Status</mat-label>
                <mat-icon matPrefix>toggle_on</mat-icon>
                <mat-select formControlName="status">
                  <mat-option value="ON">ON</mat-option>
                  <mat-option value="OFF">OFF</mat-option>
                </mat-select>
                <mat-error>Status is required</mat-error>
              </mat-form-field>

              <div class="form-actions">
                <button mat-raised-button color="primary" type="submit" [disabled]="submitting" class="submit-btn">
                  <mat-spinner *ngIf="submitting" diameter="20" />
                  <mat-icon *ngIf="!submitting">{{ editingId ? 'save' : 'add' }}</mat-icon>
                  {{ submitting ? 'Saving...' : (editingId ? 'Update Asset' : 'Add Asset') }}
                </button>
                <button mat-stroked-button type="button" *ngIf="editingId" (click)="cancelEdit()">
                  Cancel
                </button>
              </div>
            </form>
          </mat-card-content>
        </mat-card>

        <!-- Assets Grid -->
        <div>
          <div *ngIf="loadingAssets" class="loading-center"><mat-spinner diameter="36" /></div>

          <div *ngIf="!loadingAssets">
            <!-- Stats row -->
            <div class="stats-row">
              <div class="stat-chip pumps">
                <mat-icon>power</mat-icon>
                <span>{{ pumpCount }} Pumps</span>
              </div>
              <div class="stat-chip tanks">
                <mat-icon>water</mat-icon>
                <span>{{ tankCount }} Tanks</span>
              </div>
              <div class="stat-chip active">
                <mat-icon>check_circle</mat-icon>
                <span>{{ activeCount }} Active</span>
              </div>
            </div>

            <!-- Asset cards grouped by village -->
            <div *ngFor="let group of assetGroups" class="village-group">
              <div class="group-label">
                <mat-icon>location_on</mat-icon> {{ group.villageName }}
              </div>
              <div class="asset-grid">
                <mat-card *ngFor="let asset of group.assets" class="asset-card"
                          [class.pump-card]="asset.type==='PUMP'"
                          [class.tank-card]="asset.type==='TANK'">
                  <mat-card-content>
                    <div class="asset-top">
                      <mat-icon class="asset-type-icon">{{ asset.type === 'PUMP' ? 'settings' : 'water_damage' }}</mat-icon>
                      <span class="status-badge" [class.on]="asset.status==='ON'" [class.off]="asset.status==='OFF'">
                        <span class="dot"></span>{{ asset.status }}
                      </span>
                    </div>
                    <div class="asset-name">{{ asset.name }}</div>
                    <div class="asset-type-label">{{ asset.type }}</div>
                    <div class="asset-actions">
                      <button mat-icon-button color="primary" (click)="editAsset(asset)" matTooltip="Edit">
                        <mat-icon>edit</mat-icon>
                      </button>
                      <button mat-icon-button color="warn" (click)="deleteAsset(asset)" matTooltip="Delete">
                        <mat-icon>delete</mat-icon>
                      </button>
                    </div>
                  </mat-card-content>
                </mat-card>
              </div>
            </div>

            <div *ngIf="assets.length === 0" class="no-data">No assets registered yet.</div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; max-width: 1200px; }
    .page-header { margin-bottom: 24px; }
    .page-title { font-size: 24px; font-weight: 600; margin: 0 0 4px; color: #1a237e; }
    .page-subtitle { font-size: 14px; color: #666; margin: 0; }

    .two-col {
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 20px;
      align-items: start;
    }

    .form-card { border-radius: 12px !important; }
    .header-icon { color: #1a237e; background: #e8eaf6; border-radius: 50%; padding: 6px; }
    .full-width { width: 100%; }

    .form-actions { display: flex; gap: 8px; margin-top: 8px; }
    .submit-btn { flex: 1; height: 48px; display: flex; align-items: center; justify-content: center; gap: 8px; }

    .loading-center { display: flex; justify-content: center; padding: 60px; }

    .stats-row {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }

    .stat-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
    }
    .stat-chip mat-icon { font-size: 16px; width: 16px; height: 16px; }
    .stat-chip.pumps { background: #e8eaf6; color: #3949ab; }
    .stat-chip.tanks { background: #e0f2f1; color: #00695c; }
    .stat-chip.active { background: #e8f5e9; color: #2e7d32; }

    .village-group { margin-bottom: 20px; }

    .group-label {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 14px;
      font-weight: 600;
      color: #444;
      margin-bottom: 10px;
      padding-left: 4px;
    }

    .group-label mat-icon { font-size: 18px; width: 18px; color: #888; }

    .asset-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
      gap: 12px;
    }

    .asset-card {
      border-radius: 12px !important;
      border-top: 3px solid transparent;
      transition: box-shadow .2s;
    }
    .asset-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .pump-card { border-top-color: #1565c0 !important; }
    .tank-card { border-top-color: #00695c !important; }

    .asset-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 10px;
    }

    .asset-type-icon {
      font-size: 28px;
      width: 28px;
      height: 28px;
      color: #888;
    }

    .asset-name { font-weight: 600; font-size: 14px; color: #1a1a1a; margin-bottom: 2px; }
    .asset-type-label { font-size: 12px; color: #888; margin-bottom: 8px; }

    .asset-actions {
      display: flex;
      gap: 0;
      justify-content: flex-end;
      margin-top: 4px;
    }

    .status-badge {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600;
    }
    .status-badge .dot { width: 6px; height: 6px; border-radius: 50%; }
    .status-badge.on { background: #e8f5e9; color: #2e7d32; }
    .status-badge.on .dot { background: #4caf50; }
    .status-badge.off { background: #fce4ec; color: #c62828; }
    .status-badge.off .dot { background: #ef5350; }

    .no-data { text-align: center; padding: 60px; color: #999; }

    @media (max-width: 900px) {
      .two-col { grid-template-columns: 1fr; }
    }
  `]
})
export class AssetsComponent implements OnInit {
  assetForm: FormGroup;
  villages: Village[] = [];
  assets: Asset[] = [];
  submitting = false;
  loadingAssets = true;
  editingId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private snack: MatSnackBar
  ) {
    this.assetForm = this.fb.group({
      villageId: [null, Validators.required],
      name: ['', Validators.required],
      type: ['', Validators.required],
      status: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.api.getVillages().subscribe(v => this.villages = v);
    this.loadAssets();
  }

  loadAssets(): void {
    this.loadingAssets = true;
    this.api.getAllAssets().subscribe({
      next: (assets) => { this.assets = assets; this.loadingAssets = false; },
      error: () => { this.loadingAssets = false; }
    });
  }

  get assetGroups(): { villageName: string; assets: Asset[] }[] {
    const map = new Map<string, Asset[]>();
    for (const a of this.assets) {
      if (!map.has(a.villageName)) map.set(a.villageName, []);
      map.get(a.villageName)!.push(a);
    }
    return Array.from(map.entries()).map(([villageName, assets]) => ({ villageName, assets }));
  }

  get pumpCount(): number { return this.assets.filter(a => a.type === 'PUMP').length; }
  get tankCount(): number { return this.assets.filter(a => a.type === 'TANK').length; }
  get activeCount(): number { return this.assets.filter(a => a.status === 'ON').length; }

  onSubmit(): void {
    if (this.assetForm.invalid) { this.assetForm.markAllAsTouched(); return; }
    this.submitting = true;

    const action = this.editingId
      ? this.api.updateAsset(this.editingId, this.assetForm.value)
      : this.api.createAsset(this.assetForm.value);

    action.subscribe({
      next: (asset) => {
        if (this.editingId) {
          this.assets = this.assets.map(a => a.id === this.editingId ? asset : a);
          this.snack.open('Asset updated!', 'Close', { duration: 3000 });
          this.editingId = null;
        } else {
          this.assets = [...this.assets, asset];
          this.snack.open('Asset added!', 'Close', { duration: 3000 });
        }
        this.assetForm.reset();
        this.submitting = false;
      },
      error: () => {
        this.snack.open('Operation failed.', 'Close', { duration: 3000 });
        this.submitting = false;
      }
    });
  }

  editAsset(asset: Asset): void {
    this.editingId = asset.id;
    this.assetForm.patchValue({
      villageId: asset.villageId,
      name: asset.name,
      type: asset.type,
      status: asset.status
    });
  }

  cancelEdit(): void {
    this.editingId = null;
    this.assetForm.reset();
  }

  deleteAsset(asset: Asset): void {
    if (!confirm(`Delete "${asset.name}"?`)) return;
    this.api.deleteAsset(asset.id).subscribe({
      next: () => {
        this.assets = this.assets.filter(a => a.id !== asset.id);
        this.snack.open('Asset deleted.', 'Close', { duration: 3000 });
      },
      error: () => { this.snack.open('Delete failed.', 'Close', { duration: 3000 }); }
    });
  }
}
