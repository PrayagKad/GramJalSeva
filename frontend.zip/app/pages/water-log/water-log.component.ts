import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { ApiService } from '../../services/api.service';
import { Village, WaterLog } from '../../models/models';

@Component({
  selector: 'app-water-log',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, MatTableModule,
    MatProgressSpinnerModule, MatProgressBarModule, MatSnackBarModule, MatDividerModule
  ],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h2 class="page-title">Water Logs</h2>
          <p class="page-subtitle">Record and view daily water supply data</p>
        </div>
      </div>

      <div class="two-col">
        <!-- Form -->
        <mat-card class="form-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">add_circle</mat-icon>
            <mat-card-title>Add New Log</mat-card-title>
            <mat-card-subtitle>Enter today's water supply data</mat-card-subtitle>
          </mat-card-header>
          <mat-card-content>
            <form [formGroup]="logForm" (ngSubmit)="onSubmit()">

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Village</mat-label>
                <mat-icon matPrefix>location_on</mat-icon>
                <mat-select formControlName="villageId">
                  <mat-option *ngFor="let v of villages" [value]="v.id">{{ v.name }}</mat-option>
                </mat-select>
                <mat-error>Village is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Tank Level (%)</mat-label>
                <mat-icon matPrefix>water</mat-icon>
                <input matInput type="number" formControlName="tankLevel" min="0" max="100" />
                <mat-hint>Enter value between 0 and 100</mat-hint>
                <mat-error>Tank level must be between 0 and 100</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Pump Status</mat-label>
                <mat-icon matPrefix>power</mat-icon>
                <mat-select formControlName="pumpStatus">
                  <mat-option value="ON">ON</mat-option>
                  <mat-option value="OFF">OFF</mat-option>
                </mat-select>
                <mat-error>Pump status is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Water Quality</mat-label>
                <mat-icon matPrefix>science</mat-icon>
                <mat-select formControlName="quality">
                  <mat-option value="GOOD">GOOD</mat-option>
                  <mat-option value="BAD">BAD</mat-option>
                </mat-select>
                <mat-error>Water quality is required</mat-error>
              </mat-form-field>

              <button mat-raised-button color="primary" class="full-width submit-btn"
                      type="submit" [disabled]="submitting">
                <mat-spinner *ngIf="submitting" diameter="20" />
                <mat-icon *ngIf="!submitting">save</mat-icon>
                <span>{{ submitting ? 'Saving...' : 'Save Log' }}</span>
              </button>
            </form>
          </mat-card-content>
        </mat-card>

        <!-- Filters + Table -->
        <mat-card class="table-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">list_alt</mat-icon>
            <mat-card-title>Log History</mat-card-title>
            <div class="header-spacer"></div>
            <mat-form-field appearance="outline" class="filter-field">
              <mat-label>Filter by Village</mat-label>
              <mat-select [(value)]="selectedVillage" (selectionChange)="onVillageFilter($event.value)">
                <mat-option [value]="null">All Villages</mat-option>
                <mat-option *ngFor="let v of villages" [value]="v.id">{{ v.name }}</mat-option>
              </mat-select>
            </mat-form-field>
          </mat-card-header>

          <mat-card-content>
            <div *ngIf="loadingLogs" class="loading-center"><mat-spinner diameter="36" /></div>

            <table mat-table [dataSource]="logs" *ngIf="!loadingLogs" class="full-width">

              <ng-container matColumnDef="timestamp">
                <th mat-header-cell *matHeaderCellDef>Date & Time</th>
                <td mat-cell *matCellDef="let row">{{ row.timestamp | date:'dd MMM yy, hh:mm a' }}</td>
              </ng-container>

              <ng-container matColumnDef="villageName">
                <th mat-header-cell *matHeaderCellDef>Village</th>
                <td mat-cell *matCellDef="let row">
                  <span class="village-chip">{{ row.villageName }}</span>
                </td>
              </ng-container>

              <ng-container matColumnDef="tankLevel">
                <th mat-header-cell *matHeaderCellDef>Tank Level</th>
                <td mat-cell *matCellDef="let row">
                  <div class="tank-cell">
                    <mat-progress-bar mode="determinate" [value]="row.tankLevel"
                      [color]="row.tankLevel < 30 ? 'warn' : 'primary'" class="inline-bar" />
                    <span [class]="getTankClass(row.tankLevel)">{{ row.tankLevel }}%</span>
                  </div>
                </td>
              </ng-container>

              <ng-container matColumnDef="pumpStatus">
                <th mat-header-cell *matHeaderCellDef>Pump</th>
                <td mat-cell *matCellDef="let row">
                  <span class="status-badge" [class.on]="row.pumpStatus==='ON'" [class.off]="row.pumpStatus==='OFF'">
                    <span class="dot"></span>{{ row.pumpStatus }}
                  </span>
                </td>
              </ng-container>

              <ng-container matColumnDef="quality">
                <th mat-header-cell *matHeaderCellDef>Quality</th>
                <td mat-cell *matCellDef="let row">
                  <span class="quality-badge" [class.good]="row.quality==='GOOD'" [class.bad]="row.quality==='BAD'">
                    <mat-icon>{{ row.quality === 'GOOD' ? 'check' : 'close' }}</mat-icon>
                    {{ row.quality }}
                  </span>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="cols"></tr>
              <tr mat-row *matRowDef="let row; columns: cols;"></tr>

              <tr class="mat-row" *matNoDataRow>
                <td class="mat-cell no-data" [attr.colspan]="cols.length">No logs found.</td>
              </tr>
            </table>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; max-width: 1200px; }
    .page-header { margin-bottom: 24px; }
    .page-title { font-size: 24px; font-weight: 600; margin: 0 0 4px; color: #1a237e; }
    .page-subtitle { font-size: 14px; color: #666; margin: 0; }

    .two-col {
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 20px;
      align-items: start;
    }

    .form-card, .table-card { border-radius: 12px !important; }

    .header-icon { color: #1a237e; background: #e8eaf6; border-radius: 50%; padding: 6px; }
    .header-spacer { flex: 1; }

    .full-width { width: 100%; }

    .submit-btn {
      height: 48px;
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .filter-field { width: 160px; font-size: 13px; }

    .loading-center { display: flex; justify-content: center; padding: 40px; }

    .village-chip {
      background: #e8eaf6; color: #3949ab;
      padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500;
    }

    .tank-cell { display: flex; align-items: center; gap: 8px; min-width: 130px; }
    .inline-bar { width: 80px; border-radius: 4px; }

    .tank-good { color: #2e7d32; font-weight: 600; font-size: 13px; }
    .tank-warn { color: #f57f17; font-weight: 600; font-size: 13px; }
    .tank-critical { color: #c62828; font-weight: 600; font-size: 13px; }

    .status-badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;
    }
    .status-badge .dot { width: 7px; height: 7px; border-radius: 50%; }
    .status-badge.on { background: #e8f5e9; color: #2e7d32; }
    .status-badge.on .dot { background: #4caf50; }
    .status-badge.off { background: #fce4ec; color: #c62828; }
    .status-badge.off .dot { background: #ef5350; }

    .quality-badge {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;
    }
    .quality-badge mat-icon { font-size: 14px; width: 14px; height: 14px; }
    .quality-badge.good { background: #e8f5e9; color: #2e7d32; }
    .quality-badge.bad { background: #fce4ec; color: #c62828; }

    .no-data { text-align: center; padding: 32px; color: #999; }

    @media (max-width: 900px) {
      .two-col { grid-template-columns: 1fr; }
    }
  `]
})
export class WaterLogComponent implements OnInit {
  logForm: FormGroup;
  villages: Village[] = [];
  logs: WaterLog[] = [];
  submitting = false;
  loadingLogs = true;
  selectedVillage: number | null = null;
  cols = ['timestamp', 'villageName', 'tankLevel', 'pumpStatus', 'quality'];

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private snack: MatSnackBar
  ) {
    this.logForm = this.fb.group({
      villageId: [null, Validators.required],
      tankLevel: [null, [Validators.required, Validators.min(0), Validators.max(100)]],
      pumpStatus: ['', Validators.required],
      quality: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.api.getVillages().subscribe(v => this.villages = v);
    this.loadLogs();
  }

  loadLogs(): void {
    this.loadingLogs = true;
    this.api.getAllWaterLogs().subscribe({
      next: (logs) => {
        this.logs = logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        this.loadingLogs = false;
      },
      error: () => { this.loadingLogs = false; }
    });
  }

  onVillageFilter(villageId: number | null): void {
    this.loadingLogs = true;
    if (!villageId) {
      this.api.getAllWaterLogs().subscribe({
        next: (logs) => {
          this.logs = logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          this.loadingLogs = false;
        }
      });
    } else {
      this.api.getWaterLogsByVillage(villageId).subscribe({
        next: (logs) => { this.logs = logs; this.loadingLogs = false; }
      });
    }
  }

  onSubmit(): void {
    if (this.logForm.invalid) { this.logForm.markAllAsTouched(); return; }
    this.submitting = true;
    this.api.createWaterLog(this.logForm.value).subscribe({
      next: (log) => {
        this.snack.open('Water log saved successfully!', 'Close', { duration: 3000 });
        this.logForm.reset();
        this.logs = [log, ...this.logs];
        this.submitting = false;
      },
      error: () => {
        this.snack.open('Failed to save log. Try again.', 'Close', { duration: 3000 });
        this.submitting = false;
      }
    });
  }

  getTankClass(level: number): string {
    if (level >= 60) return 'tank-good';
    if (level >= 30) return 'tank-warn';
    return 'tank-critical';
  }
}
