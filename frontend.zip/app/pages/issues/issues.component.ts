import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ApiService } from '../../services/api.service';
import { Issue, Village } from '../../models/models';

@Component({
  selector: 'app-issues',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, MatTableModule, MatChipsModule,
    MatProgressSpinnerModule, MatSnackBarModule, MatButtonToggleModule, MatTooltipModule
  ],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h2 class="page-title">Issue Management</h2>
          <p class="page-subtitle">Report issues and track their resolution status</p>
        </div>
      </div>

      <div class="two-col">
        <!-- Report Form -->
        <mat-card class="form-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">report_problem</mat-icon>
            <mat-card-title>Report Issue</mat-card-title>
            <mat-card-subtitle>Describe the problem in the field</mat-card-subtitle>
          </mat-card-header>
          <mat-card-content>
            <form [formGroup]="issueForm" (ngSubmit)="onSubmit()">

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Village</mat-label>
                <mat-icon matPrefix>location_on</mat-icon>
                <mat-select formControlName="villageId">
                  <mat-option *ngFor="let v of villages" [value]="v.id">{{ v.name }}</mat-option>
                </mat-select>
                <mat-error>Village is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Issue Title</mat-label>
                <mat-icon matPrefix>title</mat-icon>
                <input matInput formControlName="title" placeholder="e.g. Pipe leakage near well" />
                <mat-error>Title is required</mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Description</mat-label>
                <textarea matInput formControlName="description" rows="4"
                  placeholder="Describe the issue in detail..."></textarea>
              </mat-form-field>

              <button mat-raised-button color="warn" class="full-width submit-btn"
                      type="submit" [disabled]="submitting">
                <mat-spinner *ngIf="submitting" diameter="20" />
                <mat-icon *ngIf="!submitting">send</mat-icon>
                <span>{{ submitting ? 'Submitting...' : 'Report Issue' }}</span>
              </button>
            </form>
          </mat-card-content>
        </mat-card>

        <!-- Issues Table -->
        <mat-card class="table-card">
          <mat-card-header>
            <mat-icon mat-card-avatar class="header-icon">list_alt</mat-icon>
            <mat-card-title>All Issues</mat-card-title>
            <div class="header-spacer"></div>
            <mat-button-toggle-group [(value)]="filterStatus" (change)="onFilterChange()">
              <mat-button-toggle value="">All</mat-button-toggle>
              <mat-button-toggle value="OPEN">Open</mat-button-toggle>
              <mat-button-toggle value="RESOLVED">Resolved</mat-button-toggle>
            </mat-button-toggle-group>
          </mat-card-header>

          <mat-card-content>
            <div *ngIf="loadingIssues" class="loading-center"><mat-spinner diameter="36" /></div>

            <div *ngIf="!loadingIssues" class="issues-list">
              <div *ngFor="let issue of issues" class="issue-item" [class.resolved]="issue.status === 'RESOLVED'">
                <div class="issue-top">
                  <span class="issue-title">{{ issue.title }}</span>
                  <span class="status-badge" [class.open]="issue.status==='OPEN'" [class.resolved-badge]="issue.status==='RESOLVED'">
                    <span class="dot"></span>{{ issue.status }}
                  </span>
                </div>
                <div class="issue-desc" *ngIf="issue.description">{{ issue.description }}</div>
                <div class="issue-meta">
                  <span class="village-chip">{{ issue.villageName }}</span>
                  <span class="date">{{ issue.createdAt | date:'dd MMM yyyy, hh:mm a' }}</span>
                  <button mat-stroked-button color="primary" class="resolve-btn"
                          *ngIf="issue.status === 'OPEN'"
                          [disabled]="resolvingId === issue.id"
                          (click)="resolveIssue(issue)"
                          matTooltip="Mark as resolved">
                    <mat-icon>check_circle</mat-icon>
                    {{ resolvingId === issue.id ? 'Resolving...' : 'Resolve' }}
                  </button>
                </div>
              </div>
              <div *ngIf="issues.length === 0" class="no-data">No issues found.</div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; max-width: 1200px; }
    .page-header { margin-bottom: 24px; }
    .page-title { font-size: 24px; font-weight: 600; margin: 0 0 4px; color: #1a237e; }
    .page-subtitle { font-size: 14px; color: #666; margin: 0; }

    .two-col {
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 20px;
      align-items: start;
    }

    .form-card, .table-card { border-radius: 12px !important; }
    .header-icon { color: #1a237e; background: #e8eaf6; border-radius: 50%; padding: 6px; }
    .header-spacer { flex: 1; }
    .full-width { width: 100%; }

    .submit-btn {
      height: 48px; margin-top: 8px;
      display: flex; align-items: center; justify-content: center; gap: 8px;
    }

    .loading-center { display: flex; justify-content: center; padding: 40px; }

    .issues-list { display: flex; flex-direction: column; gap: 12px; padding-top: 8px; }

    .issue-item {
      border: 1px solid #e0e0e0;
      border-radius: 10px;
      padding: 14px 16px;
      background: white;
      transition: box-shadow .2s;
    }

    .issue-item:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
    .issue-item.resolved { background: #fafafa; border-color: #e8f5e9; }

    .issue-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 8px;
      margin-bottom: 6px;
    }

    .issue-title { font-weight: 600; font-size: 14px; color: #1a1a1a; }

    .issue-desc {
      font-size: 13px;
      color: #666;
      margin-bottom: 10px;
      line-height: 1.5;
    }

    .issue-meta {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
    }

    .village-chip {
      background: #e8eaf6; color: #3949ab;
      padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500;
    }

    .date { font-size: 12px; color: #999; }

    .resolve-btn {
      margin-left: auto;
      font-size: 12px;
      height: 32px;
      line-height: 32px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }

    .resolve-btn mat-icon { font-size: 16px; width: 16px; height: 16px; }

    .status-badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 10px; border-radius: 12px; font-size: 12px;
      font-weight: 600; white-space: nowrap;
    }
    .status-badge .dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
    .status-badge.open { background: #fff3e0; color: #e65100; }
    .status-badge.open .dot { background: #ff9800; }
    .status-badge.resolved-badge { background: #e8f5e9; color: #2e7d32; }
    .status-badge.resolved-badge .dot { background: #4caf50; }

    .no-data { text-align: center; padding: 40px; color: #999; }

    @media (max-width: 900px) {
      .two-col { grid-template-columns: 1fr; }
    }
  `]
})
export class IssuesComponent implements OnInit {
  issueForm: FormGroup;
  villages: Village[] = [];
  issues: Issue[] = [];
  submitting = false;
  loadingIssues = true;
  filterStatus = '';
  resolvingId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private snack: MatSnackBar
  ) {
    this.issueForm = this.fb.group({
      villageId: [null, Validators.required],
      title: ['', Validators.required],
      description: ['']
    });
  }

  ngOnInit(): void {
    this.api.getVillages().subscribe(v => this.villages = v);
    this.loadIssues();
  }

  loadIssues(): void {
    this.loadingIssues = true;
    this.api.getAllIssues(this.filterStatus || undefined).subscribe({
      next: (issues) => {
        this.issues = issues.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        this.loadingIssues = false;
      },
      error: () => { this.loadingIssues = false; }
    });
  }

  onFilterChange(): void {
    this.loadIssues();
  }

  onSubmit(): void {
    if (this.issueForm.invalid) { this.issueForm.markAllAsTouched(); return; }
    this.submitting = true;
    this.api.createIssue(this.issueForm.value).subscribe({
      next: (issue) => {
        this.snack.open('Issue reported successfully!', 'Close', { duration: 3000 });
        this.issueForm.reset();
        this.issues = [issue, ...this.issues];
        this.submitting = false;
      },
      error: () => {
        this.snack.open('Failed to report issue.', 'Close', { duration: 3000 });
        this.submitting = false;
      }
    });
  }

  resolveIssue(issue: Issue): void {
    this.resolvingId = issue.id;
    this.api.resolveIssue(issue.id).subscribe({
      next: (updated) => {
        const idx = this.issues.findIndex(i => i.id === issue.id);
        if (idx !== -1) this.issues[idx] = updated;
        this.issues = [...this.issues];
        this.snack.open('Issue marked as resolved!', 'Close', { duration: 3000 });
        this.resolvingId = null;
      },
      error: () => { this.resolvingId = null; }
    });
  }
}
