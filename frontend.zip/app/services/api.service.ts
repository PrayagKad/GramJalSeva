import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  Village, User, WaterLog, WaterLogRequest,
  Issue, IssueRequest, Asset, AssetRequest, DashboardData
} from '../models/models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private base = 'http://localhost:8080/api';

  constructor(private http: HttpClient) {}

  // Auth
  login(phone: string, password: string): Observable<User> {
    return this.http.post<User>(`${this.base}/auth/login`, { phone, password });
  }

  // Villages
  getVillages(): Observable<Village[]> {
    return this.http.get<Village[]>(`${this.base}/villages`);
  }

  // Dashboard
  getDashboard(): Observable<DashboardData> {
    return this.http.get<DashboardData>(`${this.base}/dashboard`);
  }

  // Water Logs
  createWaterLog(payload: WaterLogRequest): Observable<WaterLog> {
    return this.http.post<WaterLog>(`${this.base}/water-logs`, payload);
  }

  getAllWaterLogs(): Observable<WaterLog[]> {
    return this.http.get<WaterLog[]>(`${this.base}/water-logs`);
  }

  getWaterLogsByVillage(villageId: number): Observable<WaterLog[]> {
    return this.http.get<WaterLog[]>(`${this.base}/water-logs/village/${villageId}`);
  }

  // Issues
  getAllIssues(status?: string): Observable<Issue[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get<Issue[]>(`${this.base}/issues`, { params });
  }

  createIssue(payload: IssueRequest): Observable<Issue> {
    return this.http.post<Issue>(`${this.base}/issues`, payload);
  }

  resolveIssue(id: number): Observable<Issue> {
    return this.http.patch<Issue>(`${this.base}/issues/${id}/resolve`, {});
  }

  // Assets
  getAllAssets(): Observable<Asset[]> {
    return this.http.get<Asset[]>(`${this.base}/assets`);
  }

  createAsset(payload: AssetRequest): Observable<Asset> {
    return this.http.post<Asset>(`${this.base}/assets`, payload);
  }

  updateAsset(id: number, payload: AssetRequest): Observable<Asset> {
    return this.http.put<Asset>(`${this.base}/assets/${id}`, payload);
  }

  deleteAsset(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base}/assets/${id}`);
  }
}
