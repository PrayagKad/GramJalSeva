export interface Village {
  id: number;
  name: string;
}

export interface User {
  id: number;
  name: string;
  phone: string;
  role: 'ADMIN' | 'OPERATOR';
}

export interface WaterLog {
  id: number;
  villageId: number;
  villageName: string;
  tankLevel: number;
  pumpStatus: 'ON' | 'OFF';
  quality: 'GOOD' | 'BAD';
  timestamp: string;
}

export interface WaterLogRequest {
  villageId: number;
  tankLevel: number;
  pumpStatus: string;
  quality: string;
}

export interface Issue {
  id: number;
  title: string;
  description: string;
  status: 'OPEN' | 'RESOLVED';
  villageId: number;
  villageName: string;
  createdAt: string;
}

export interface IssueRequest {
  title: string;
  description: string;
  villageId: number;
}

export interface Asset {
  id: number;
  name: string;
  type: 'PUMP' | 'TANK';
  status: 'ON' | 'OFF';
  villageId: number;
  villageName: string;
}

export interface AssetRequest {
  name: string;
  type: string;
  status: string;
  villageId: number;
}

export interface DashboardData {
  totalIssues: number;
  resolvedIssues: number;
  openIssues: number;
  activePumps: number;
  totalAssets: number;
  latestTankLevel: number;
  latestVillageName: string;
  recentLogs: WaterLog[];
}
